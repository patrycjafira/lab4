
import { useState, useCallback, useMemo } from "react";
import type { SearchResult, Show } from "./types";
import { useFetch } from "./hooks/useFetch";
import { useDebounce } from "./hooks/useDebounce";
import { useLocalStorage } from "./hooks/useLocalStorage";
import SearchBox from "./components/SearchBox";
import ShowCard from "./components/ShowCard";

const API_URL = "https://api.tvmaze.com/search/shows?q=";

export default function App() {
  const [query, setQuery] = useState("");

  // Zadanie 2 – debounce
  const debouncedQuery = useDebounce(query.trim(), 400);

  // Zadanie 4 – ulubione
  const [favorites, setFavorites] = useLocalStorage<Show[]>(
    "lab04-favorites",
    []
  );

  const url =
    debouncedQuery.length >= 2
      ? API_URL + encodeURIComponent(debouncedQuery)
      : null;

  const { data, loading, error } = useFetch<SearchResult[]>(url);

  // Zadanie 5 – useCallback
  const toggleFavorite = useCallback((show: Show) => {
    setFavorites((prev) => {
      const exists = prev.some((item) => item.id === show.id);

      if (exists) {
        return prev.filter((item) => item.id !== show.id);
      }

      return [...prev, show];
    });
  }, [setFavorites]);

  // Zadanie 5 – useMemo
  const favoriteIds = useMemo(
    () => new Set(favorites.map((f) => f.id)),
    [favorites]
  );

  const shows = useMemo(
    () => data?.map((result) => result.show) ?? [],
    [data]
  );

  return (
    <>
      <h1>🎬 Wyszukiwarka seriali</h1>

      <SearchBox value={query} onChange={setQuery} />

      <section aria-live="polite" style={{ marginTop: 24 }}>
        {loading && <p className="muted">Szukam…</p>}

        {error && (
          <p className="error">
            Nie udało się pobrać danych: {error}
          </p>
        )}

        {!url && (
          <p className="muted">
            Wpisz co najmniej 2 znaki, aby wyszukać.
          </p>
        )}

        <div
          style={{
            display: "grid",
            gap: 12,
            gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))",
          }}
        >
          {shows.map((show) => (
            <ShowCard
              key={show.id}
              show={show}
              isFavorite={favoriteIds.has(show.id)}
              onToggleFavorite={toggleFavorite}
            />
          ))}
        </div>
      </section>

      <section style={{ marginTop: 32 }}>
        <h2>❤️ Ulubione ({favorites.length})</h2>

        {favorites.length === 0 && (
          <p className="muted">
            Nie masz jeszcze ulubionych seriali.
          </p>
        )}

        <div
          style={{
            display: "grid",
            gap: 12,
            gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))",
          }}
        >
          {favorites.map((show) => (
            <ShowCard
              key={show.id}
              show={show}
              isFavorite={true}
              onToggleFavorite={toggleFavorite}
            />
          ))}
        </div>
      </section>
    </>
  );
}
