
import { useEffect, useState } from "react";

export type FetchState<T> = {
  data: T | null;
  loading: boolean;
  error: string | null;
};

export function useFetch<T>(url: string | null): FetchState<T> {
  const [state, setState] = useState<FetchState<T>>({
    data: null,
    loading: false,
    error: null,
  });

  useEffect(() => {
    if (!url) {
      setState({
        data: null,
        loading: false,
        error: null,
      });
      return;
    }

    const controller = new AbortController();

    setState((prev) => ({
      ...prev,
      loading: true,
      error: null,
    }));

    fetch(url, { signal: controller.signal })
      .then((res) => {
        if (!res.ok) {
          throw new Error(`HTTP error: ${res.status}`);
        }

        return res.json();
      })
      .then((data: T) => {
        setState({
          data,
          loading: false,
          error: null,
        });
      })
      .catch((err: unknown) => {
        if (err instanceof Error && err.name === "AbortError") {
          return;
        }

        setState((prev) => ({
          ...prev,
          loading: false,
          error: err instanceof Error ? err.message : "Wystąpił błąd",
        }));
      });

    return () => controller.abort();
  }, [url]);

  return state;
}
