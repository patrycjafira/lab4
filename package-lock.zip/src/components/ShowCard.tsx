
import { memo } from "react";
import type { Show } from "../types";

type ShowCardProps = {
  show: Show;
  isFavorite: boolean;
  onToggleFavorite: (show: Show) => void;
};

const ShowCard = memo(function ShowCard({
  show,
  isFavorite,
  onToggleFavorite,
}: ShowCardProps) {
  return (
    <article
      style={{
        display: "flex",
        gap: 12,
        background: "var(--card)",
        border: "1px solid var(--border)",
        borderRadius: 12,
        padding: 12,
      }}
    >
      {show.image ? (
        <img
          src={show.image.medium}
          alt=""
          width={70}
          height={98}
          style={{ borderRadius: 6, objectFit: "cover" }}
        />
      ) : (
        <div
          style={{
            width: 70,
            height: 98,
            background: "var(--border)",
            borderRadius: 6,
          }}
          aria-hidden
        />
      )}

      <div style={{ flex: 1 }}>
        <h3 style={{ margin: "0 0 4px", fontSize: "1rem" }}>
          {show.name}
        </h3>

        <p className="muted" style={{ margin: 0, fontSize: ".85rem" }}>
          {show.premiered?.slice(0, 4) ?? "brak daty"} ·{" "}
          {show.genres.join(", ") || "brak gatunku"}
        </p>

        <p style={{ margin: "6px 0" }}>
          ⭐ {show.rating.average ?? "–"}
        </p>

        <button
          aria-pressed={isFavorite}
          onClick={() => onToggleFavorite(show)}
        >
          {isFavorite ? "★ W ulubionych" : "☆ Dodaj do ulubionych"}
        </button>
      </div>
    </article>
  );
});

export default ShowCard;
