
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";
import App from "./App";

describe("<App />", () => {
  beforeEach(() => {
    localStorage.clear();

    vi.stubGlobal(
      "fetch",
      vi.fn(() =>
        Promise.resolve({
          ok: true,
          json: () => Promise.resolve([]),
        })
      )
    );
  });

  it("pokazuje komunikat o braku wyników", async () => {
    const user = userEvent.setup();

    render(<App />);

    await user.type(
      screen.getByLabelText(/szukaj serialu/i),
      "breaking"
    );

    expect(
      await screen.findByText(/brak wyników/i)
    ).toBeInTheDocument();
  });
});
