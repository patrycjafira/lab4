export type Show = {
  id: number;
  name: string;
  premiered: string | null;
  genres: string[];
  rating: { average: number | null };
  image: { medium: string; original: string } | null;
};

export type SearchResult = {
  score: number;
  show: Show;
};